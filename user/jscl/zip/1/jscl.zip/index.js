const crabos = require("./conf.json");
// CrabOS@ultimate-1.0

console.clear()
console.log("------------------------")
console.log("CrabOS Ultimate");
console.log("[INFO]: Iniciando Instância...");
console.log("------------------------");

// suporte => help.crabos.ml

const express = require('express');
const cbos = express();
let error = crabos.error


cbos.listen(crabos.port, () => {
  console.log('Servidor iniciado na porta: ' + crabos.port);
  console.log("------------------------");
}); 

cbos.get('/',function(req,res){
  // On getting the home route request,
  // the user will be redirected to GFG website
  res.redirect('https://jscloud.ml');
}); 

cbos.get('/discord',function(req,res){
  // On getting the home route request,
  // the user will be redirected to GFG website
  res.redirect('https://discord.gg/xyU9seTSws');
}); 

cbos.get('*',function(req,res){
  // On getting the home route request,
  // the user will be redirected to GFG website
  res.redirect('https://jscloud.ml');
}); 