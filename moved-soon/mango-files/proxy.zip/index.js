console.log("MangoByte Redrect");
const express = require('express');
const mb = express();
mb.listen(80, () => {
  console.log('MangoByte Proxy Running');
}); 
mb.get('/',function(req,res){
  res.redirect('https://mangobyte.ml');
}); 
mb.get('*',function(req,res){
  res.redirect('https://manngobyte.ml');
}); 